﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* This class simulates the behavior of a coin box
 * 
 * Author - Sanders Tshinyama
 * Version - 1.0 (10-30-23)
 * Since - 10-30-23
 */

namespace VendingMachineProgram
{
    public class CoinBox
    {
        private List<Coin> box;

        /**
           Constructs a CoinBox object.
        */
        public CoinBox()
        {
            box = new List<Coin>();
        }

        /**
           Adds a coin.
           @param c the coin to add
        */
        public void AddCoin(Coin c)
        {
            box.Add(c);
        }

        /**
           Adds coins from one coinbox to another.
           @param other the box of coins
        */
        public void AddCoins(CoinBox other)
        {
            box.AddRange(other.box);
        }

        /**
           Gets the value of all the coins.
           @return total the total value of all the coins
        */
        public double GetValue()
        {
            double total = 0;
            foreach (Coin c in box)
            {
                total += c.Value;
            }

            return total;
        }

        /**
           Removes all the coins.
        */
        public void RemoveAllCoins()
        {
            box.Clear();
        }
    }
}
