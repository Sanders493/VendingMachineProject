﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* This class simulates the behavior of a product
 * 
 * Author - Sanders Tshinyama
 * Version - 1.0 (10-30-23)
 * Since - 10-30-23
 */

namespace VendingMachineProgram
{
    public class Product
    {
        private readonly String description;
        private readonly double price;

        public string? Description { get { return description; } }
        public double Price { get { return price; } }

        /**
           Constructs a Product object
           @param aDescription the description of the product
           @param aPrice the price of the product
        */
        public Product(String description, double price)
        {
            this.description = description;
            this.price = price;
        }

        /**
           Determines of this product is the same as the other product.
           @param other the other product
           @return true if the products are equal, false otherwise
        */
        public override Boolean Equals(Object? other)
        {
            if (other == null)
            {
                return false;
            }
            Product b = (Product)other;

            return this.description.Equals(b.description) && this.price == b.price;
        }

        /**
           Formats the product's description and price.
        */
        public override String ToString()
        {
            return this.description + " @ " + $"{this.price:C2}";
        }
    }

}
