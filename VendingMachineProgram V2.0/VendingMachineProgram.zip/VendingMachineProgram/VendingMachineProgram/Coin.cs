﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* This class simulates the behavior of a coin
 * 
 * Author - Sanders Tshinyama
 * Version - 1.0 (10-30-23)
 * Since - 10-30-23
 */

namespace VendingMachineProgram
{
    public class Coin
    {
        private readonly double value;
        private readonly String name;
        public double Value { get { return value; } }
        public String Name { get { return name; } }

        public static readonly Coin NICKEL = new(.05, "nickel");
        public static readonly Coin DIME = new(.10, "dime");
        public static readonly Coin QUARTER = new(.25, "quarter");
        public static readonly Coin DOLLAR = new(1.0, "dollar");

        /**
           Constructs a coin.
           @param aValue the monetary value of the coin.
           @param aName the name of the coin
        */
        public Coin(double value, String name)
        {
            this.value = value;
            this.name = name;
        }
        public override String ToString()
        {
            return name + " @ " + $"{value:F2}";
        }
    }
}