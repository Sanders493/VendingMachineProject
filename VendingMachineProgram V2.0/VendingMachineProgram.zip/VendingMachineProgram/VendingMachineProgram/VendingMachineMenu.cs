﻿using System;
using System.Collections.Generic;
using static System.Console;

namespace VendingMachineProgram
{
    public class VendingMachineMenu
    {
        //private Scanner in;
        private static readonly Coin[] COINS = {
        Coin.NICKEL, Coin.DIME, Coin.QUARTER, Coin.DOLLAR
    };

        /**
           Constructs a VendingMachineMenu object
        */
        /*public VendingMachineMenu()
        {
          in = new Scanner(System.in);
        }*/

        /**
           Runs the vending machine system.
           @param machine the vending machine
        */
        public void Run(VendingMachine machine)
        {
            bool more = true;

            while (more)
            {
                WriteLine("S)how products A)dd B)uy product I)nsert R)emove coins Q)uit: ");
                String command = ReadLine().ToUpper();

                if (command.Equals("S"))
                {
                    foreach (Product p in machine.GetProductTypes())
                    {
                        WriteLine(p);
                    }
                }
                else if (command.Equals("A"))
                {
                    Write("Description: ");
                    String description = ReadLine();
                    Write("Price: ");
                    double price = Double.Parse(ReadLine());
                    Write("Quantity: ");
                    int quantity = int.Parse(ReadLine());
                    machine.AddProduct(new Product(description, price), quantity);
                }
                else if (command.Equals("I"))
                {
                    Coin chosen = PickCoin();
                    WriteLine("Current $ " + machine.AddCoin(chosen));
                }
                else if (command.Equals("B"))
                {
                    Product p = PickProduct(machine.GetProductTypes());
                    String result = machine.BuyProduct(p);
                    if (result == "OK")
                    {
                        WriteLine("Purchased: " + p);
                    }
                    else
                    {
                        WriteLine("Sorry: " + result);
                    }
                }
                else if (command.Equals("R"))
                {
                    double totalInCoinBox = machine.RemoveMoney();
                    WriteLine($"Removed: {totalInCoinBox:C2}");
                }
                else if (command.Equals("Q"))
                {
                    more = false;
                }
            }
        }

        // Pick a coin from the list of all coins
        private static Coin PickCoin()
        {
            while (true)
            {
                char c = 'A';
                foreach (Coin choice in COINS)
                {
                    WriteLine(c + ") " + choice);
                    c++;
                }

                String input = ReadLine();
                int n = input.ToUpper()[0] - 'A';

                if (0 <= n && n < COINS.Length)
                {
                    return COINS[n];
                }
            }
        }

        // Pick a product from all products
        private static Product PickProduct(List<Product> allProducts)
        {
            while (true)
            {
                char c = 'A';
                foreach (Product choice in allProducts)
                {
                    WriteLine(c + ") " + choice);
                    c++;
                }
                String input = ReadLine();
                int n = input.ToUpper()[0] - 'A';
                if (0 <= n && n < allProducts.Count)
                {
                    return allProducts[n];
                }
            }
        }

        public static void Main()
        {
            new VendingMachineMenu()
               .Run(new VendingMachine());
        }
    }
}
