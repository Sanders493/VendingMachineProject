﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* This class simulates the behavior of a vending machine
 * 
 * Author - Sanders Tshinyama
 * Version - 1.0 (10-30-23)
 * Since - 10-30-23
 */

namespace VendingMachineProgram
{
    public class VendingMachine
    {
        private List<Product> products;
        public CoinBox coins;  // main coin box
        public CoinBox currentCoins; // temp for inserted coins

        /**
           Constructs a VendingMachine object.
        */
        public VendingMachine()
        {
            products = new List<Product>();
            coins = new CoinBox();
            currentCoins = new CoinBox();
        }

        /**
           Gets the type of products in the vending machine.
           @return an array of products sold in this machine.
        */
        public List<Product> GetProductTypes()
        {
            List<Product> types = new();

            for (int i = 0; i < products.Count; i++)
            {
                Product entry = products[i];
                types.Add(entry);
            }
            foreach (Product p in products)
            {
                if (! types.Contains(p))
                {
                   types.Add(p);
                }
            }
            return types;
        }

        /**
           Adds a product to the vending machine.
           @param p the product to add
           @param quantity the quantity
        */
        public void AddProduct(Product p, int quantity)
        {
            for (int i = 0; i < quantity; i++)
                products.Add(p);
        }

        /**
           Adds the coin to the vending machine.
           @param c the coin to add
        */
        public double AddCoin(Coin c)
        {
            currentCoins.AddCoin(c);
            return currentCoins.GetValue();
        }

        /**
           Buys a product from the vending machine.
           @param p the product to buy
        */
        public String BuyProduct(Product p)
        {
            for (int i = 0; i < products.Count; i++)
            {
                Product prod = products[i];
                if (prod.Equals(p))
                {
                    double payment = currentCoins.GetValue();
                    if (p.Price <= payment)
                    {
                        products.Remove(prod);
                        coins.AddCoins(currentCoins);
                        currentCoins.RemoveAllCoins();
                        return "OK";
                    }
                    else
                    {
                        return "Insufficient money";
                    }
                }
            }
            return "No such product";
        }


        /**
           Removes the money from the vending machine.
           @return the amount of money removed
        */
        public double RemoveMoney()
        {
            double r = coins.GetValue();
            coins.RemoveAllCoins();
            return r;
        }

    }
}